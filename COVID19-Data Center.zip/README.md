## Covid-data-lab

### Database
This branch is just my additions during development, will merge later
